// Chris Wilhelm cwilhel8
// Derek Dang ddang8
// Udochukwu Nwosu unwosu6

#include <string>
#include <iostream>
#include <fstream>
#include "SkipBoGame.h"
int main(int argc, char *argv[]) {
  if(argc != 5 && argc != 3) {
    std::cerr << "invalid program usage: invalid number of arguments" << std::endl;
    return 1;
  }

  //if statement for number of args
  std::string shuf = argv[1];
  bool shuffle;
  if(shuf == "true") {
    shuffle = true;
  } else if(shuf == "false") {
    shuffle = false;
  } else {
    //invalind argument error
    std::cerr << "invalid program usage: invalid first argument" << std::endl;
    return 1;
  }

  //arguments for a new game
  if(argc == 5) {
    std::string num = argv[2];
    int num_Players = stoi(num);
    std::string size = argv[3];
    int stockSize = stoi(size);
    if(num_Players > 6 || num_Players < 2) { //checks numplayers is viable
      std::cerr << "invalid program usage: num players must be 2-6" << std::endl;
      return 1;
    }
    std::cout << "num players is " << num_Players << std::endl;
    
    if(stockSize < 1) { //chekcs stock size is viable
      std::cerr << "invalid program usage: bad stock size" << std::endl;
      return 1;
    }
    if(stockSize > 30) { //chekcs stock size is viable
      std::cerr << "invalid program usage: bad stock size" << std::endl;
      return 1;
    }
    if(stockSize > 20 && num_Players == 6) { //chekcs stock size is viable
      std::cerr << "invalid program usage: bad stock size" << std::endl;
      return 1;
    }
    std::cout << "stock size is " << stockSize  << std::endl;
    //deck file opening
    std::ifstream s(argv[4]);
    if (!s.is_open()) {
      std::cerr << "invalid program usage: can't open deck file" << std::endl;
      return 1;
    } 

    //construct and execute new game
    SkipBoGame game = SkipBoGame(shuffle, num_Players, stockSize, s);
    game.Deal();
    std::cout << std::endl;
    game.PlayGame();
  }

  //read in arguments for a saved game
  if(argc == 3) {
    std::ifstream s(argv[2]);
    if (!s.is_open()) { //ensures file can be opened
      std::cerr << "invalid program usage: can't open input game file" << std::endl;
      return 1;
    }

    //construct and execute saved game
    SkipBoGame game = SkipBoGame(shuffle, s);
    game.PlayGame();
  }
  return 0;
}
